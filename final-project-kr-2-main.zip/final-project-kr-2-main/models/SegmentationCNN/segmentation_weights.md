# SegmentationCNN Weights

[url](https://drive.google.com/drive/u/1/folders/1FYd0wr1z-rWan-QcicnOOco846HlYPcV)