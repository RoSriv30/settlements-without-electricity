# FCNResnetTransfer Weights

[url](https://drive.google.com/drive/u/1/folders/1As8EhNXAYyTnqk1iirur3pXJd0ZhiNIf)